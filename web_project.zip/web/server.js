//Required modules
var express = require('express'); //Imports and loads all the function of express module
//Making server using express
var app = express(); //Express can make many applications but here its use for one only
var User = require('./userSchema.js'); //Importing the schema file
var bodyParser = require('body-parser'); //Imports and loads all the function of body-parser module
var mongoose = require('mongoose'); //Imports and loads all the function of mongoose module

//Using Body parser for middleware
app.use(bodyParser.urlencoded({ extended: false })); 
//Only parses urlencoded bodies and only looks at requests where the Content-Type header matches the type option. 
// Extended false To avoid posting nested object 
app.use(bodyParser.json({strict:false}));
//Only parses json bodies and only looks at requests where the Content-Type header matches the type option. 
// Extended false To accept all values that json.parse accepts

//use method for static files
app.use(express.static(__dirname));

//Connecting to mongodb loaclhost database
mongoose.connect("mongodb://127.0.0.1:27017/datours",{ useNewUrlParser: true });


app.get("/",function(req, res){
    console.log("okay");
    res.sendFile(__dirname + "/index.html");
});

//Post Method
app.post('/adduser',function(req, res){
      var data = req.body;
      //console.log("okay");
      //console.log(req);
      var user=new User(data);
      console.log(user);
      user.save(function(err,user,numAffected){
      if(err){
            //console.log(err);
            res.send('500');
          }
       if(numAffected){
        console.log("added",user);
        res.send(user);
       }
});
});

//Listening to port-number
app.listen(3000, function(){
    console.log("localhost at 3000");
});
